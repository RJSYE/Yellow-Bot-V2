from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

@app.route('/')
def index():
    """bad_words 테이블을 초기화하고 cnt 칼럼을 추가"""
    conn = sqlite3.connect('../filter_words.db')
    c = conn.cursor()
    
    # bad_words 테이블이 존재하는지 확인하고 없으면 생성
    c.execute('''
        CREATE TABLE IF NOT EXISTS bad_words (
            word TEXT UNIQUE,
            cnt INTEGER DEFAULT 1
        )
    ''')

    # bad_words 테이블에서 단어 리스트를 가져옴
    c.execute('SELECT cnt, word FROM bad_words')
    result = c.fetchall()
    
    # 모든 행의 값을 리스트로 변환하고 정렬
    column_data = [row for row in result]
    column_data.sort(reverse=True)

    # 데이터베이스 연결 종료
    conn.close()

    # 리스트를 템플릿으로 넘겨주어 웹 페이지에 출력
    return render_template('index.html', words=column_data)

@app.route("/add", methods=["GET", "POST"])
def add():
    if request.method == "POST":
        # 폼에서 입력한 단어를 가져옴
        new_word = request.form.get("word")

        # 데이터베이스에 새 단어를 추가
        conn = sqlite3.connect('../filter_words.db')
        c = conn.cursor()

        # 이미 존재하는 단어인지 확인한 후 없으면 추가
        c.execute('''
            INSERT OR IGNORE INTO bad_words (word) VALUES (?)
        ''', (new_word,))
        
        conn.commit()
        conn.close()

        # 추가 후 홈 화면으로 리디렉션
        return redirect(url_for('index'))
    
    # GET 요청일 때는 폼이 있는 페이지를 렌더링
    return render_template('add.html')

@app.route('/search', methods=['GET'])
def search():
    keyword = request.args.get('word')
    query = 'SELECT cnt, word FROM bad_words WHERE word=?'
    conn = sqlite3.connect('../filter_words.db')
    c = conn.cursor()
    c.execute(query, (keyword,))
    result = c.fetchall()
    print(result)
    return render_template('index.html', words=result)

@app.route("/delete")
def delete():
    return "delete"

if __name__ == '__main__':
    app.run(debug=True)
